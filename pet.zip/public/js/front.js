$(document).ready(function () {

  $('.carousel').carousel({
    interval: 2000
  })
  
  //formulario
  $('#form-contato').validate({
    rules: {
      nome: 'required',
      email: 'required',
      telefone: 'required',
      assunto: 'required',
      mensagem: 'required'

    },
    messages: {
      nome: 'Insira o nome',
      email: 'Insira a mensagem',
      telefone: 'Insira o telefone',
      assunto: 'Insira o assunto',
      mensagem: 'Insira a mensagem'

    },
    errorPlacement: function (error, element) {
      error.insertAfter(element).addClass('text-danger');
    },
    errorClass: "is-invalid"
  });

  //calendario

  var calendar = $('#calendar').fullCalendar({
    timeZone: 'America/Sao_Paulo',
    axisFormat: 'H:mm',
    timeFormat: {
      agenda: 'H:mm{ - H:mm}',
    },
    monthNames: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
    monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
    dayNames: ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sabado'],
    dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'],

    buttonText: {
      today: 'Hoje',
      month: 'Mês',
      week: 'Semana',
      day: 'Hoje',
      list: 'Lista'
    },
    defaultView: 'agendaDay',
    eventBorderColor: "#de1f1f",

    header: {
      left: 'prev,next,today',
      center: 'title',
      right: 'month,agendaWeek,agendaDay'
    },

    defaultDate: 'today',
    navLinks: true, // can click day/week names to navigate views
    selectable: true,
    selectHelper: true,

    eventos: [{
      id: '',
      title: '',
      start: '',
      end: '',
    }],

    eventClick: function (event, element) {
      // Display the modal and set the values to the event values.
      $('.modal').modal('show');
      $('.modal').find('#title').val(event.title);
      $('.modal').find('#starts-at').val(event.starts_at);
      $('.modal').find('#ends-at').val(event.ends_at)
    },
    editable: true,
    eventLimit: true, // allow "more" link when too many events
  });
})
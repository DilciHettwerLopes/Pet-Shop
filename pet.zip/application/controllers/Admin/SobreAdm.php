<?php
defined('BASEPATH') or exit('No direct script access allowed');

class SobreAdm extends CI_Controller
{
    private $data;

    public function __construct()
    {
        parent::__construct();
        $this->data['url'] = $this->config->base_url();
        $this->load->model('Admin/SobreAdm_model');
        $this->load->library('form_validation');
    }
    public function index()
    {
        $this->load->view('admin/includesadm/header', $this->data);
        $this->data['sobre'] = $this->SobreAdm_model->get_all();
        $this->load->view('admin/sobreadm/list', $this->data);
        $this->load->view('admin/includesadm/footer', $this->data);
    }

    public function delete($id)
    {
        $this->load->view('admin/includesadm/header', $this->data);
        if (!empty($id) && is_numeric($id)) {
            $sobre = $this->SobreAdm_model->get_where(array('id' => $id));
            if ($sobre) {
                unlink('uploads/sobre/' . $sobre->imagem);
                $this->SobreAdm_model->delete(array('id' => $id));
                $this->session->set_flashdata('mensagem', '<div class="alert alert-success"> Historia removida com sucesso.</div>');
            } else {
                $this->session->set_flashdata('mensagem', '<div class="alert alert-danger"> Historia não existente.</div>');
            }
        }
        redirect(base_url('admin/sobreadm'));
        $this->load->view('admin/includesadm/footer', $this->data);
    }

    public function create()
    {
        $this->load->view('admin/includesadm/header', $this->data);
        $this->data['titulo'] = '';
        $this->data['id'] = '';
        $this->data['action'] = base_url('admin/sobreadm/create_action');
        $this->dataa['descricao'] = set_value('descricao');
        $this->data['imagem'] = set_value('imagem');
        $this->load->view('admin/sobreadm/form', $this->data);
        $this->load->view('admin/includesadm/footer', $this->data);
    }
    public function create_action()
    {

        $this->_validationRules();
       
        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $insert = array(
                'titulo' => $this->input->post('titulo'),
                'descricao' => $this->input->post('descricao'),
                'imagem' => $this->input->post('imagem'),
            );
            $sobre = $this->SobreAdm_model->insert($insert);
            if ($sobre) {
                $this->_configsUpload();
                if (!$this->upload->do_upload('imagem')) {
                    $this->session->set_flashdata('mensagem', $this->upload->display_errors());
                    redirect(base_url('admin/sobreadm'));
                    exit();
                } else {
                    $upload = $this->upload->data();
                    $this->SobreAdm_model->update($sobre, array('imagem' => $upload['file_name']));
                }
                $this->session->set_flashdata('mensagem', '<div class="alert alert-success"> Historia cadastrada com sucesso.</div>');
            } else {
                $this->session->set_flashdata('mensagem', '<div class="alert alert-danger"> Falha ao cadastrar a histori.</div>');
            }
            redirect(base_url('admin/sobreadm/form'));
            $this->load->view('admin/includesadm/footer', $this->data);
        }
    }
    public function update($id)
    {
        
        $this->load->view('admin/includesadm/header', $this->data);
        $sobre = $this->SobreAdm_model->get_where(array('id' => $id));
        if ($sobre) {
            $this->data['titulo'] = $sobre->titulo;
            $this->data['id'] = $sobre->id;
            $this->data['action'] = base_url('admin/sobreadm/update_action/' . $sobre->id);
            $this->data['descricao'] = $sobre->descricao;
            $this->data['imagem'] = $sobre->imagem;
            $this->load->view('admin/sobreadm/form', $this->data);
        } else {
            $this->session->set_flashdata('mensagem', '<div class="alert alert-danger"> Historia não encontrada.</div>');
            redirect(base_url('admin/sobreadm'));
            $this->load->view('admin/includesadm/footer', $this->data);
        }
    }
    public function update_action($id)
    {
       
        $this->_validationRules();
        if ($this->form_validation->run() == FALSE) {
            $this->update($id);
        } else {
            $imagem = $this->input->post('imagem_aux');
            if ($_FILES['imagem']['titulo']) {
                $config = $this->_configsUpload();
                if (!$this->upload->do_upload('imagem')) {
                    $this->session->set_flashdata('mensagem', $this->upload->display_errors());
                    redirect(base_url('admin/sobreadm'));
                    exit();
                } else {
                    unlink($config['upload_path'] . $imagem);
                    $upload = $this->upload->data();
                    $imagem = $upload['file_name'];
                  
                }
            }
            $update = array(
                'titulo' => $this->input->post('titulo'),
                'descricao' => $this->input->post('descricao'),
                'imagem' => $imagem,
            );
            if ($this->SobreAdm_model->update($id, $update)) {
                $this->session->set_flashdata('mensagem', '<div class="alert alert-success"> Historia alterada com sucesso.</div>');
            } else {
                $this->session->set_flashdata('mensagem', '<div class="alert alert-danger"> Falha ao alterar a historia.</div>');
            }
            redirect(base_url('admin/sobreadm'));
            $this->load->view('admin/includesadm/footer', $this->data);
        }
    }
    final function _configsUpload()
    {
        $config['upload_path']          = './uploads/sobre/';
        @mkdir($config['upload_path']);
        $config['allowed_types']        = 'gif|jpg|png|pdf';
        $config['max_size']             = 2048;
        $config['max_width']            = 2048;
        $config['max_height']           = 2048;
        $config['encrypt_name']         = true;
        $this->load->library('upload', $config);
        return $config;
    }
    final function _validationRules()
    {
        $this->form_validation->set_rules('titulo', 'titulo', 'required');
        $this->form_validation->set_rules('descricao', 'descricao', 'required');
        
    }
}

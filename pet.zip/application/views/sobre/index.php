  <!-- Barra de navegação -->
  <div class="navigation">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?= base_url() ?>">Página Inicial</a></li>
        <li class="breadcrumb-item"> <a href="<?= base_url('sobre') ?>">Sobre</a></li>
      </ol>
    </nav>


    <h4>Conheça um pouco mais da nossa historia.</h4> <br>

    <?php
    foreach ($sobre as $s) {
    ?>
    

      <div class="row featurette">
        <div class="col-md-7">
          <h2 class="featurette-heading"><?= $s->titulo ?></h2>
          <p class="lead"><?= $s->descricao ?></p>
        </div>
        <div class="col-md-5">
          <img src="<?= $this->config->item('base_url_cdn') ?>uploads/sobre/<?= $s->imagem ?>" class="rounded float-left" alt="<?= $s->titulo ?>" height="200">
        </div>
      </div>
      <hr class="featurette-divider">
    <?php
    }
    ?>
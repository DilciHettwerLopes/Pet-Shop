<!-- Barra de navegação -->
<div class="navigation">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?= base_url() ?>">Página Inicial</a></li>
      <li class="breadcrumb-item"><a href="<?= base_url('produtos') ?>">Produtos</a></li>
    </ol>
  </nav>
</div>

<h1>Produtos</h1>
<p>Conheça os nossos produtos</p>
<div class="container">
  <div class="row mb-2">
    <?php
    foreach ($produtos as $p) {
    ?>
      <div class="col-md-4 container-fluid d-flex flex-wra">
        <div class="card mb-4 box-shadow w-80">
          <img class="card-img-top" height="200" width="150" src="uploads/produtos/<?= $p->imagem ?>" alt="<?= $p->titulo ?>" width="200" height="200" alt="...">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title"><?= $p->titulo ?></h5>
            <!--  <select class="btn btn-dark btn" name="categoria">
            <option value="valor1"><?= $p->categoria ?></option>
          </select> -->
            <p class="card-text"><?= $p->descricao ?>
            </p>
                      
                <a href="<?= base_url('produtos/detalhes/' . $p->id) ?>" class="btn btn-primary mt-auto">Saiba mais</a>
              </div>
            
          
        </div>
      </div>
    <?php
    }
    ?>
   
  </div>
  


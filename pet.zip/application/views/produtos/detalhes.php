<!-- Barra de navegação -->
<div class="navigation">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?=base_url()?>">Página Inicial</a></li>
      <li class="breadcrumb-item"><a href="<?=base_url('produtos')?>">Produtos</a></li>
    </ol>
  </nav>
</div>

<h2><?= $produto->titulo?></h2>
<p><?=$produto->descricao?></p>
<img src="<?=$this->config->item('base_url_cdn')?>uploads/produtos/<?=$produto->imagem?>"  class="w-25" 
height="200" alt="...">
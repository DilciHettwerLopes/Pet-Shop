<!--carousel-->
<div id="carousel" class="carousel slide mb-3" data-bs-ride="carousel">
    <ol class="carousel-indicators">
        <li data-bs-target="#carousel" data-bs-slide-to="0" class="active"></li>
        <li data-bs-target="#carousel" data-bs-slide-to="1"></li>
        <li data-bs-target="#carousel" data-bs-slide-to="2"></li>
    </ol>

    <div class="carousel-inner">
        <div class="carousel-item active" data-bs-interval="10000">
            <img src="uploads/1.jpg" class="d-block img-fluid" alt="...">
        </div>
        <div class="carousel-item">
            <img src="uploads/2.jpg" class="d-block img-fluid" alt="...">
        </div>
        <div class="carousel-item">
            <img src="uploads/adocao.jpg" class="d-block img-fluid" alt="...">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Anterior</span>
    </a>
    <a class="carousel-control-next" href="#carousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Proximo</span>
    </a>
</div>


<!-- Botão Agenda-->
<div class="row mb-2">
    <div class="col-md-6">
        <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <p class="card-text mb-auto">Para maior comodidade e agilidade no atendimento clique no botão a baixo e veja
                    quais os dias e horários disponiveis.</p>
                <a href="<?= base_url('agenda') ?>" class="stretched-link"></a>
                <button type="submit" class="btn btn-success btn-lg" id="button">Agende aqui o seu serviço</button>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="uploads/botao.jpg" class="card-img" style="max-width: 200px" alt="...">
            </div>
        </div>
    </div>

    <!-- Amigo Bicho-->
    <div class="col-md-6">
        <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <p class="mb-auto">Apoiamos a ONG Amigo Bicho, para mais informações entre em contato aqui.</p>
                <a href="<?= base_url('adocao') ?>" class="btn btn-success btn-lg">Saiba mais</a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="uploads/amigo bicho.jpg" class="card-img" style="max-width: 260px" alt="...">
            </div>
        </div>
    </div>
</div>


<!-- Linha -->
<hr class="my-4">

<!--Google map-->
<div class="card mb-5">
    <div class="card-header"> Onde nos encontrar:</div>
    <div class="card-body">
        <div id="map-container-google-1" class="z-depth-1-half map-container" style="height: 300px">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14253.969645526988!2d-53.52589759999999!3d-26.728658251992208!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94fa5c5f9cf04df1%3A0x402acc9154c0bae4!2sFaculdade%20Senac%20S%C3%A3o%20Miguel%20do%20Oeste!5e0!3m2!1spt-BR!2sbr!4v1585542689278!5m2!1spt-BR!2sbr" frameborder="0" style="border:0" allowfullscreen>
            </iframe>
        </div>
    </div>
<div class="container">
  <h1>Adoção</h1>

  <a href="<?= base_url('Admin/AdocaoAdm/create'); ?>" class="btn btn-primary mb-3">Cadastrar Adoção</a>
  <?= !empty($this->session->userdata('mensagem')) ? $this->session->userdata('mensagem') : null; ?>

  <table class="table table-striped" data-toggle="data-tables" style="width:100%">
    <thead>
      <tr>
        <th scope="col" width=5%>Id</th>
        <th scope="col" width=20%>Nome do animal</th>
        <th scope="col" width=10%>Raça</th>
        <th scope="col" width=30%>Descricao</th>
        <th scope="col" width=15%>Imagem</th>
        <th scope="col" width=20%>Opções</th>
      </tr>
    </thead>
    <tbody>
      <?php
      foreach ($adocoes as $a) {
      ?>

        <tr>
          <td ><?= $a->id; ?></td>
          <td ><?= $a->nome_animal; ?></td>
          <td ><?= $a->raca; ?></td>
          <td ><?= $a->descricao; ?></td>
          <td ><img src="<?= base_url('uploads/adocao/' . $a->imagem) ?>" alt="<?= $a->nome_animal ?>" width='40'></td>
          <td >
            <a class="btn btn-success" href="<?= base_url('admin/adocaoAdm/update/' . $a->id) ?>">Alterar</a>
            <a class="btn btn-danger" href="<?= base_url('admin/adocaoAdm/delete/' . $a->id) ?>">Apagar</a>
          </td>
        </tr>
      <?php

      } ?>
    </tbody>
  </table>
<fieldset>
  <div class="container mb-3">
    <div class="row">
      <div class="container">

        <!-- Barra de navegação -->
        <div class="navigation">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?= $url . 'admin/sobreadm' ?>">Sobre</a></li>
              <li class="breadcrumb-item"><a href=""><?= ($id) ? "Alterar" : "Cadastrar"; ?> Historia </a></li>
            </ol>
          </nav>
        </div>


        <nav class="navbar navbar-expand-lg navbar-light bg-light col-12 mb-3">
          <legend><?= $titulo ?></legend>
          <?php echo validation_errors(); ?>
        </nav>
      </div>
    </div>

    <form method="POST" action="<?= $action ?>" class="form-horizontal" id="form-cadastro">
    <div class="form-group">
      <label for="titulo">Titulo</label>
        <input type="text" value="<?= $titulo ?>" class="form-control" name="titulo" placeholder="Digite o titulo">
      </div>
      <div class="form-group">
      <label for="titulo">Descrição</label>
        <textarea class="form-control" id="summernote" name="descricao" placeholder="Digite o descrição"></textarea>
      </div>
      <input name="imagem" type="file">
      <?php
      if (!empty($imagem)) {
        echo "<img src='" . $url . "uploads/{$imagem}" . "' width='150'>";
        echo "<input type='hidden' value='{$imagem}' name='imagem_aux'>";
      }
      ?>
      <div class="mt-4 pb-4">
        <button type="submit" class="btn btn-success">Gravar</button>
      </div>
    </form>
  </div>
</fieldset>
<?php
?>
 

<!-- orientações 
controler private data 

     view <?=$url; ?> caminho -->
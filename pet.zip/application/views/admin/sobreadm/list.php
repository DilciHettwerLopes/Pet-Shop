<div class="container">
  <h1>Dados sobre a empresa</h1>

  <a href="<?= $url . 'Admin/sobreadm/create' ?>" class="btn btn-primary mb-3">Cadastrar historia </a>
  <?= !empty($this->session->userdata('mensagem')) ? $this->session->userdata('mensagem') : null; ?>

  <table class="table table-striped" data-toggle="data-tables" style="width:100%">
    <thead>
      <tr>
        <th scope="col" width="5%">Id</th>
        <th scope="col" width="10%">Titulo</th>
        <th scope="col" width="45%">Descricao</th>
        <th scope="col" width="20%">Imagem</th>
        <th scope="col" width="20%">Opções</th>
      </tr>
    </thead>
    <tbody>
      <?php
      foreach ($sobre as $s) {
      ?>

        <tr>
          <td ><?= $s->id; ?></td>
          <td ><?= $s->titulo; ?></td>
          <td ><?= $s->descricao; ?></td>
          <td ><img src="<?= $url . 'uploads/sobre/' . $s->imagem; ?>" alt="<?= $s->titulo ?>" width='40'></td>
          <td>
        
            <a class="btn btn-success" href="<?= $url . 'Admin/SobreAdm/update/' . $s->id ?>">Alterar</a>
            <a class="btn btn-danger" href="<?= $url . 'Admin/SobreAdm/delete/' . $s->id ?>">Apagar</a>
         
          </td>
        </tr>
      <?php
      } ?>
    </tbody>
  </table>
<fieldset>
  <div class="container-fluid">
    <div class="row">
      <div class="container">

        <!-- Barra de navegação -->
        <div class="navigation">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?= $url . 'admin/produtosadm' ?>">Produtos</a></li>
              <li class="breadcrumb-item"><a href="<?= $url . 'admin/produtosadm/create' ?>">Cadastrar Produto</a></li>
            </ol>
          </nav>
          <nav class="navbar navbar-expand-lg navbar-light col-12">
            <legend><?=$titulo?></legend>
            <?php echo validation_errors(); ?>
          </nav>

          <!-- formulario -->
          <form enctype="multipart/form-data" method="post" id="table" action="<?= $action ?>" id="form-cadastro">
            <div class="form-group">
              <label for="titulo">Titulo</label>
              <input type="text" class="form-control" name="titulo" value="<?= $titulo ?>" placeholder="Digite o titulo"><br>
            </div>
            <div class="form-group">
              <label for="descricao">Descricao</label>
              <input type="text" class="form-control" name="descricao" value="<?= $descricao ?>" id="summernote" placeholder="Digite a descrição"><br>
            </div>
            <div class="form-group">
              <input name="imagem" type="file">
              <?php
              if (!empty($imagem)) {
                echo "<img src='" . $url . "uploads/{$imagem}" . "' width='150'>";
                echo "<input type='hidden' value='{$imagem}' name='imagem_aux'>";
              }
              ?>
            </div>
            <input type="submit" class="btn btn-success" value="Salvar">
          </form>
        </div>
      </div>
    </div>
  </div>
</fieldset>
<div class="container">
  <h1>Produtos</h1>

  <a href="<?= $url . 'Admin/ProdutosAdm/create' ?>" class="btn btn-primary mb-3">Cadastrar Produto</a>
  <?= !empty($this->session->userdata('mensagem')) ? $this->session->userdata('mensagem') : null; ?>


  <!-- tabela lista de produtos -->
  <table class="table table-striped" data-toggle="data-tables" style="width:100%">
    <thead>
      <tr>
        <th scope="col" width=5%>Id</th>
        <th scope="col" width="20%">Titulo</th>
        <th scope="col" width="30%">Descricao</th>
        <th scope="col" width="15%">Categoria</th>
        <th scope="col" width="10%">Imagem</th>
        <th scope="col" width="20%">Opções</th>
      </tr>
    </thead>
    <tbody>
      <?php
      foreach ($produtos as $p) {
      ?>

        <tr>
          <td width=5%><?= $p->id; ?></td>
          <td width="10%"><?= $p->titulo; ?></td>
          <td width="30%"><?= $p->descricao; ?></td>
          <td width="15%"><?= $p->categoria; ?></td>
          <td width="20%"><img src="<?= $url . 'uploads/produtos/' . $p->imagem; ?>" alt="<?= $p->titulo ?>" width='40'></td>
          <td width="20%">
            <a class="btn btn-success" href="<?= $url . 'admin/produtosAdm/update/' . $p->id ?>">Alterar</a>
            <a class="btn btn-danger" href="<?= $url . 'admin/produtosAdm/delete/' . $p->id ?>">Apagar</a>
          </td>
        </tr>
      <?php
      } ?>
    </tbody>
  </table>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!--  -->
  <link rel="stylesheet" href="<?= $url; ?>public/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?= $url; ?>public/css/all.min.css">
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/chosen-js@1.8.7/chosen.min.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/5.0.9/css/fileinput.min.css" media="all" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="<?= $url; ?>public/css/DataTables/datatables.min.css" />
  <link rel="stylesheet" href="<?= $url; ?>public/css/style.css">
  <title>Sistema de Gestão</title>

</head>

<body>
  <div class="container text-right md-3">
    Bem-vindo(a) <?= $this->session->userdata('nome') ?><br>
    <a class="nav-link" href="<?= base_url('login/logout') ?>">Sair</a>

    <!-- nav bar -->
    <div class="md-3">
      <nav class="navbar navbar-expand-lg navbar-light bg-primary mb-2">

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-link active" href="<?= base_url('admin/servicosadm') ?>">Gerenciar serviços<span class="sr-only">(current)</span></a>
            <a class="nav-link active" href="<?= base_url('admin/sobreadm') ?>">Gerenciar Sobre</a>
            <a class="nav-link active" href="<?= base_url('admin/produtosadm') ?>"> Gerenciar Produtos</a>
            <a class="nav-link active" href="<?= base_url('admin/adocaoadm') ?>">Gerenciar Adoção</a>
          </div>
          </form>
        </div>
      </nav>
    </div>
  </div>

  <body>
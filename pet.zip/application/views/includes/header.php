<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="stylesheet" href="public/css/style.css">
  <link href="http://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css" />-->
  <link rel="stylesheet" href="public/css/all.min.css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css" />
  

  <title>Pet Mimo</title>
</head>

<body>
  <div class="container">

    <!-- nav bar -->
    <div class="md-3">
      <nav class="navbar navbar-expand-lg navbar-light bg-primary mb-2">
        <!--logo-->
        <img src="uploads/logo.png" width="70">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-link active" href="<?= base_url() ?>">Inicio <span class="sr-only">(current)</span></a>
            <a class="nav-link" href="<?= base_url('sobre') ?>">Sobre</a>
            <a class="nav-link" href="<?= base_url('servicos') ?>">Serviços</a>
            <a class="nav-link" href="<?= base_url('produtos') ?>">Produtos</a>
            <a class="nav-link" href="<?= base_url('adocao') ?>">Adoção</a>
            <a class="nav-link" href="<?= base_url('contato') ?>">Contato</a>
            <a class="nav-link" href="<?= base_url('agenda') ?>">Agenda</a>
          </div>
          <div class="navbar-nav ml-md-auto">
            <form class="form-inline my-2 my-lg-0">
              <input class="form-control mr-sm-2" type="search" placeholder="" aria-label="Search">
              <button class="btn btn-outline-dark my-2 my-sm-0" type="submit"><strong>Pesquisar</strong></button>
            </form>
          </div>
        </div>
    </div>
    </nav>
  </div>
  <div class="container">
    
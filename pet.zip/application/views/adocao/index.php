<!-- Barra de navegação -->
<div class="navigation">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?= base_url() ?>">Página Inicial</a></li>
      <li class="breadcrumb-item"><a href="<?= base_url('Adocao') ?>">Adoção</a></li>
    </ol>
  </nav>
</div>
<h3>Conheça nossos animaizinhos que estão a procura de um lar.</h3>
<div data-aos="fade-up" data-aos-anchor-placement="center-bottom">
  <img src="uploads/adocao.jpg" width="1110" height="500" alt="...">
</div>
<br>
<!-- adocoes-->
<div class="container-fluid">
  <div class="row ">

    <?php
    foreach ($animais as $a) {
    ?>

      <div class="col-md-6">
        <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
          <div class="col p-4 d-flex flex-column position-static">
            <p class="card-text mb-auto"><?= $a->nome_animal ?></p>
            <p class="card-text mb-auto"><?= $a->raca ?></p>
            <p class="card-text mb-auto"><?= $a->descricao ?></p>
            <a href="<?= base_url('adocao/detalhes/' . $a->id) ?>" class="btn btn-primary">Mais detalhes</a>
          </div>
          <div class="col-auto d-none d-lg-block">
            <img src="uploads/adocao/<?= $a->imagem ?>" class="card-img" style="max-width: 150px" alt="<?= $a->nome_animal ?>">
          </div>
        </div>
      </div>

    <?php
    }
    ?>

  </div>
  <br>

  <div class="row featurette">
    <div class="col-md-12">
      <h2 class="featurette-heading">Amigo Bicho</h2>
      <p class="lead"><strong>Nas compras acima de R$ 100,00, doamos 5% para a ONG Amigo Bicho castrar os bichinhos.</strong></p>
    </div>
    <div class="col-md-5">
      <img src="uploads/amigo bicho.jpg" class="rounded float-left" alt=" " height="200">
    </div>
  </div>
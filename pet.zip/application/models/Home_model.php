<?php

class Produtos_model extends CI_Model
{
    public function getList()    {
    }
}

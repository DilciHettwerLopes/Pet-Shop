<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="stylesheet" href="public/css/style.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="public/css/all.min.css">
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/chosen-js@1.8.7/chosen.min.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/5.0.9/css/fileinput.min.css" media="all" rel="stylesheet" type="text/css" />

  <title>Pet Mimo</title>
</head>

<body>
<div class="container">
  <!--login-->
<a class="nav-link text-right text-dark" href="<?= base_url('login') ?> ">Faça seu login aqui</a>
  <!-- nav bar -->
  <div class="md-3">
    <nav class="navbar navbar-expand-lg navbar-light bg-primary mb-2">
     
        <img src="uploads/logo.jpg" width="65">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-link active" href="<?= base_url() ?>">Inicio <span class="sr-only">(current)</span></a>
            <a class="nav-link" href="<?= base_url('sobre') ?>">Sobre</a>
            <a class="nav-link" href="<?= base_url('servicos') ?>">Serviços</a>
            <a class="nav-link" href="<?= base_url('produtos') ?>">Produtos</a>
            <a class="nav-link" href="<?= base_url('adocao') ?>">Adoção</a>
            <a class="nav-link" href="<?= base_url('contato') ?>">Contato</a>
          </div>
          <div class="navbar-nav ml-md-auto">
            <form class="form-inline my-2 my-lg-0">
              <input class="form-control mr-sm-2" type="search" placeholder="" aria-label="Search">
              <button class="btn btn-outline-dark my-2 my-sm-0" type="submit"><strong>Pesquisar</strong></button>
            </form>
          </div>
        </div>
      </div>
    </nav>
  </div>
  <div class="container">
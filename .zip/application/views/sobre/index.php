  <!-- Barra de navegação -->
  <div class="navigation">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?= base_url() ?>">Página Inicial</a></li>
        <li class="breadcrumb-item"> <a href="<?= base_url('sobre') ?>">Sobre</a></li>
      </ol>
    </nav>
  

  <h4>Conheça um pouco mais da nossa historia.</h4> <br>

  <?php
  foreach ($sobre as $s) {
  ?>
    <div class="card mb-5">
      <div class="row ">
        <div class="col-md-4">
          <img src="<?= $this->config->item('base_url_cdn') ?>uploads/historia/<?= $s->imagem ?>" class="card-img-left" alt="<?= $s->titulo ?>" height="200">
        </div>
        <div class="col-md-5">
          <div class="card-body">
            <h5 class="card-title"><?= $s->titulo ?></h5>
            <p class="card-text"><?= $s->descricao ?></p>
          </div>
        </div>
      </div>
    </div>

  <?php
  }
  ?>
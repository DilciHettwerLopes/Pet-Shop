<!-- Barra de navegação -->
<div class="navigation">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?=base_url()?>">Página Inicial</a></li>
      <li class="breadcrumb-item"><a href="<?=base_url('servicos')?>">Serviços</a></li>
    </ol>
  </nav>
</div>

<h2><?=$servico->titulo?></h2>
<p><?=$servico->descricao?></p>
<img src="<?=$this->config->item('base_url_cdn')?>uploads/servicos/<?=$servico->imagem?>" width="300" 
height="200" alt="...">
<!-- Barra de navegação -->
<div class="navigation">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?=base_url()?>">Página Inicial</a></li>
      <li class="breadcrumb-item"><a href="<?=base_url('servicos')?>">Serviços</a></li>
    </ol>
  </nav>
</div>

<h4>Conheça os nossos serviços</h4>
<div class="row mb-2">
  <?php
  foreach ($servicos as $s) {
  ?>
    <div class="col-md-4">
      <div class="card mb-4 box-shadow">
        <img class="card-img-top" height="200" src="uploads/servicos/<?=$s->imagem?>" alt="<?= $s->titulo ?>">
        <div class="card-body">
          <h5 class="card-title"><?= $s->titulo ?></h5>
          <p class="card-text"><?= $s->descricao ?>
          </p>
          <div class="d-flex justify-content-between align-items-center">
            <div class="btn-group">
              <a href="<?= base_url('servicos/detalhes/' . $s->id) ?>" class="btn btn-primary">+ detalhes</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php
  }
  ?>
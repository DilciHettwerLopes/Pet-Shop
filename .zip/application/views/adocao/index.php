<!-- Barra de navegação -->
<div class="navigation">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?=base_url()?>">Página Inicial</a></li>
      <li class="breadcrumb-item"><a href="<?=base_url('Adocao')?>">Adoção</a></li>
    </ol>
  </nav>
</div>
<h3>Conheça nossos animaizinhos que estão a procura de um lar.</h3>
<div data-aos="fade-up"
     data-aos-anchor-placement="center-bottom">
  <img src="uploads/adocao.jpg" width="1110" height="500" alt="...">
</div>
<div class="mt-4">
  <div class="row mt-5">
    <?php
    foreach ($animais as $a) {
    ?>
      <div class="col-4 md-3">
        <div class="card">
          <img class="card-img-top" height="250" width="150" src="uploads/adocao/<?= $a->imagem ?>" alt="<?= $a->nome_animal ?>">
          <div class="card-body">
            <h5 class="card-title"><?= $a->nome_animal ?></h5>
            <p class="card-text"><?= $a->raca ?></p>
            <p class="card-text"><?= $a->descricao ?></p>
            <a href="<?= base_url('adocao/detalhes/' . $a->id) ?>" class="btn btn-primary">Mais detalhes</a>
          </div>
        </div>
      </div>
    <?php
    }
    ?>
  </div>
  <br>
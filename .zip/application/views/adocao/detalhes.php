<!-- Barra de navegação -->
<div class="navigation">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?=base_url()?>">Página Inicial</a></li>
      <li class="breadcrumb-item"><a href="<?=base_url('Adocao')?>">Adoção</a></li>
    </ol>
  </nav>
</div>

<h2><?= $adocao->nome_animal ?>
</h2>
<p><?= $adocao->raca?></p>
<p><?= $adocao->descricao ?></p>
<img src="<?= $this->config->item('base_url_cdn')?>uploads/adocao/<?=$adocao->imagem?>">
<h1>Serviços</h1>

<?= anchor(base_url('Admin/ServicosAdm/create'), 'Cadastrar serviço'); ?>
<?= !empty($this->session->userdata('mensagem')) ? $this->session->userdata('mensagem') : null; ?>
<?php
?>
<!--if (!empty($servicos))-->
<tbody>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    echo '<table border="1" cellpadding="4" cellspacing="0" class>';
  </nav>
  <table class="table table-striped" data-toggle="data-tables" style="width:100%">
    <thead>
      <tr>
        <th scope="col">Id</th>
        <th scope="col">Titulo</th>
        <th scope="col">Descricao</th>
        <th scope="col">Imagem</th>
        <th scope="col">Opções</th>
      </tr>
    </thead>
</tbody>
<?php
foreach ($servicos as $k) {
?>
  <tr>
      <td>{$k->id}</td>
      <td>{$k->titulo}</td>
      <td>{$k->descricao}</td>
      <td><img src='uploads/{$k->imagem}' width='40'></td>
      <td>anchor(;</td>
      <td>anchor(base_url('Admin/ServicosAdm/delete/' . $k->id), 'Apagar');</td>
      <td>
        <a class="btn btn-secondary fa fa-pencil" href="<?=base_url('admin/servicosAdm/update/' . $s->id)?>"></a>
        <a class="btn btn-danger fa fa-trash" href="<?= base_url('admin/servicosAdm/delete/' . $s->id) ?>"></a>
      </td>
    </tr>
}
}
<h1>Serviços</h1>

<?= anchor(base_url('Admin/ServicosAdm/create'), 'Cadastrar serviço'); ?>
<?= !empty($this->session->userdata('mensagem')) ? $this->session->userdata('mensagem') : null; ?>
<?php
?>
<!--if (!empty($servicos))-->
<tbody>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    echo '<table border="1" cellpadding="4" cellspacing="0" class>';
  </nav>
  <table class="table table-striped" data-toggle="data-tables" style="width:100%">
    <thead>
      <tr>
        <th scope="col">Id</th>
        <th scope="col">Titulo</th>
        <th scope="col">Descricao</th>
        <th scope="col">Imagem</th>
        <th scope="col">Opções</th>
      </tr>
    </thead>
</tbody>
<?php
foreach ($servicos as $k) {
?>
  <tr>
      <td><?= $p->id_produto; ?></td>
      <td><?= $p->nome; ?></td>
      <td><?= $p->categoria; ?></td>
      <td><?= $p->marca; ?></td>
      <td><?= $p->descricao; ?></td>
      <td><img src='<?= base_url('uploads/produtos/' . $p->arquivo) ?>' width='40'></td>
      <td>
        <a class="btn btn-secondary fa fa-pencil" href="<?= base_url('admin/produtosAdm/update/' . $p->id_produto) ?>"></a>

        <a class="btn btn-danger fa fa-trash" href="<?= base_url('admin/produtosAdm/delete/' . $p->id_produto) ?>"></a>
      </td>
    </tr>
echo '<tr>';
  echo "<td>{$k->id}</td>";
  echo "<td>{$k->titulo}</td>";
  echo "<td>{$k->descricao}</td>";
  echo "<td><img src='uploads/{$k->imagem}' width='40'></td>";
  echo "<td>";
    echo anchor(base_url('servicos/update/' . $k->id), 'Alterar');
    echo ' | ';
    echo anchor(base_url('servicos/delete/' . $k->id), 'Apagar');
    echo "</td>";
  echo "</tr>";
echo '</table>';
?>
}





  foreach ($produtos as $p) {
  ?>
    
  <?php

  } ?>
</tbody>
</table>
</div>
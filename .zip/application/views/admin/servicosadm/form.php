<fieldset>
  <div class="container-fluid">
    <div class="row">
      <nav class="navbar navbar-expand-lg navbar-light bg-light col-12">
        <legend><?= $titulo ?></legend>
        <?php echo validation_errors(); ?>
      </nav>
    </div>
  </div>
  <form enctype="multipart/form-data" method="post" action="<?= $action ?>">
    <div class="table table">
      <div class="panel-body"> <br>
        <div class="form-row">
          <div class="col-12 md-5">
            <input type="text" name="titulo" value="<?= $titulo ?>" placeholder="Digite o titulo"><br> 
            <input type="text" name="descricao" value="<?= $descricao ?>" placeholder="Digite a descrição"><br>
            <input name="imagem" type="file">
            <?php
            if (!empty($imagem)) {
              echo "<img src='" . base_url("uploads/{$imagem}") . "' width='150'>";
              echo "<input type='hidden' value='{$imagem}' name='imagem_aux'>";
            }
            ?> <br> <br>
            <input type="submit" class="btn btn-success" value="Salvar">
          </div>
        </div>
      </div>
  </form>
</fieldset>
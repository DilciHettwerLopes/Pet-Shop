<h1>Adoção</h1>
<?=anchor(base_url('adocao/create'),'Cadastrar animal para adoção');?>

<?=!empty($this->session->userdata('mensagem'))?$this->session->userdata('mensagem'):null;?>
<?php
if(!empty($adocao)){
	echo '<table border="1" width="100%">';
	echo '<tr><th>Id</th><th>Título</th><th>Descrição</th><th>Tipo</th><th>Imagem</th><th>Opções</th></tr>';
	foreach ($adocoes as $p){
		echo '<tr>';
			echo "<td>{$p->id}</td>";
			echo "<td>{$p->titulo}</td>";
			echo "<td>{$p->descricao}</td>";
			echo "<td><img src='uploads/adocoes/{$p->imagem}' width='40'></td>";
			echo "<td>";
				echo anchor(base_url('adocoes/update/'.$p->id),'Alterar');
				echo ' | ';
				echo anchor(base_url('adocoes/delete/'.$p->id),'Apagar');
			echo "</td>";
		echo "</tr>";
	}
	echo '</table>';
}


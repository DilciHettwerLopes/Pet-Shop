<fieldset>
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
		<a href="<?= base_url('ProdutosAdm/create') ?>" class="btn btn-primary">Cadastrar Produtos </a>
		</a>
	</nav>
	<form enctype="multipart/form-data" method="post" action="<?= $action ?>">
		<div class="table table-secondary">
			<div class="container">
				<div class="panel-body"> <br>
					<div class="form-row">
						<div class="col-2">
							<label for="inputCategoria">Categoria</label>
							<input type="text" class="form-control" placeholder="Categoria" name="categoria" value="<?= $categoria ?>">
						</div>
						<div class="col-6">
							<label for="inputNome">Titulo</label>
							<input type="text" class="form-control" placeholder="Nome" name="nome" value="<?= $nome ?>">
						</div>
						<div class="col-12 form-group">
							<label for="inputDescricao">Descrição</label>
							<textarea class="form-control" id="inputDescricao" name="descricao" value="<?= $descricao ?>" rows="3"></textarea>
						</div>
					</div>
					<div class="col-4 form-row">
						<div class="form-group">
							<label for="inputImagem">Imagem</label>
							<input type="file" class="form-control-file" name="arquivo" id="arquivo">
							<?php
							if (!empty($arquivo)) {
								echo "<img src='" . base_url("uploads/produtos{$arquivo}") . "' width='150'>";
								echo "<input type='hidden' value='{$arquivo}' name='arquivo_aux'>";
							}
							?>

						</div>
						<br>
					</div>
					<button type="submit" class="btn btn-primary  " name="Gravar" value="Gravar">Gravar</button>
				</div>
				<br>
			</div>
		</div>
	</form>
</fieldset>
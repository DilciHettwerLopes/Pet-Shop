<nav class="navbar navbar-expand-lg navbar-light bg-light">

	<a href="<?= base_url('admin/produtosAdm/create') ?>" class="btn btn-primary">Cadastrar Produtos </a>
	</a>
</nav>

<table class="table table-striped" data-toggle="data-tables" style="width:100%">
	<thead>
		<tr>
			<th scope="col">#</th>
			<th scope="col">Nome</th>
			<th scope="col">Categoria</th>
			<th scope="col">Marca</th>
			<th scope="col">Descrição</th>
			<th scope="col">Imagem</th>
			<th scope="col">Opções</th>
		</tr>
	</thead>
	<tbody>
		<?php

		foreach ($produtos as $p) {
		?>
			<tr>
				<td><?= $p->id_produto; ?></td>
				<td><?= $p->nome; ?></td>
				<td><?= $p->categoria; ?></td>
				<td><?= $p->marca; ?></td>
				<td><?= $p->descricao; ?></td>
				<td><img src='<?= base_url('uploads/produtos/' . $p->arquivo) ?>' width='40'></td>
				<td>
					<a class="btn btn-secondary fa fa-pencil" href="<?= base_url('admin/produtosAdm/update/' . $p->id_produto) ?>"></a>

					<a class="btn btn-danger fa fa-trash" href="<?= base_url('admin/produtosAdm/delete/' . $p->id_produto) ?>"></a>
				</td>
			</tr>
		<?php

		} ?>
	</tbody>
</table>
</div>

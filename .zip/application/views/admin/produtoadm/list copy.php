<h1>Produtos</h1>
<?=anchor(base_url('produtos/create'),'Cadastrar produto');?>
<?=(3)?>
<?=!empty($this->session->userdata('mensagem'))?$this->session->userdata('mensagem'):null;?>
<?php
if(!empty($produtos)){
	echo '<table border="1" width="100%">';
	echo '<tr><th>Id</th><th>Título</th><th>Descrição</th><th>Tipo</th><th>Imagem</th><th>Opções</th></tr>';
	foreach ($produtos as $p){
		echo '<tr>';
			echo "<td>{$p->id}</td>";
			echo "<td>{$p->titulo}</td>";
			echo "<td>{$p->descricao}</td>";
			echo "<td><img src='uploads/produtos/{$p->imagem}' width='40'></td>";
			echo "<td>";
				echo anchor(base_url('produtos/update/'.$p->id),'Alterar');
				echo ' | ';
				echo anchor(base_url('produtos/delete/'.$p->id),'Apagar');
			echo "</td>";
		echo "</tr>";
	}
	echo '</table>';
}


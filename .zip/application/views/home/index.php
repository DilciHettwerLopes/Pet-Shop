<!--carroussel-->
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="uploads/1.jpg" width="1100" height="500" alt="...">
        </div>
        <div class="carousel-item">
            <img src="uploads/2.jpg" width="1100" height="500" alt="...">
        </div>
        <div class="carousel-item">
            <img src="uploads/adocao.jpg" width="1100" height="500" alt="...">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Proximo</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Anterior</span>
    </a>
</div>
<!-- Botão Agenda-->
<div class="text-center mt-5">
    <button type="submit" class="btn btn-outline-success btn-lg" id="formsend">Agende aqui o banho e tosa </button>
</div>


<!--Google map-->
<hr class="my-4">
<!-- Linha -->
<div class="card mb-5">
    <div class="card-header">Onde nos encontrar:</div>
    <div class="card-body">
        <div id="map-container-google-1" class="z-depth-1-half map-container" style="height: 300px">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14253.969645526988!2d-53.52589759999999!3d-26.728658251992208!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94fa5c5f9cf04df1%3A0x402acc9154c0bae4!2sFaculdade%20Senac%20S%C3%A3o%20Miguel%20do%20Oeste!5e0!3m2!1spt-BR!2sbr!4v1585542689278!5m2!1spt-BR!2sbr" frameborder="0" style="border:0" allowfullscreen>
            </iframe>
        </div>
    </div>
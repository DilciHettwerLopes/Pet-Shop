<?php

if ($_POST) {
            extract($_POST);
            if (empty($nome) || empty($assunto) || empty($email) || empty($mensagem)) {
                echo '<div class="alert alert-danger">Preencha corretamente todos os campos obrigatórios.</div>';
            } else {
                $mensagem = $nome . ' - ' . $telefone . ' - ' . $mensagem;
                if (mail("dilcylopes@gmail.com", $assunto, $mensagem)) {
                    echo '<div class="alert alert-sucesso">Mensagem enviada com sucesso.</div>';
                } else {
                    echo '<div class="alert alert-danger">Falha ao enviar a mensagem.</div>';
                }
            }
        }

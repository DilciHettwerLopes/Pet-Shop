<?php

class HomeAdm extends MY_Controller{

 public function index(){
    $this->load->view('homeadm/index');

 }

}
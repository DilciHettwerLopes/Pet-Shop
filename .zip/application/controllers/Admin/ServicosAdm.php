<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ServicosAdm extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Admin/ServicosAdm_model');
        $this->load->library('form_validation');
    }
    public function index()
    {
        $data['servicos'] = $this->ServicosAdm_model->get_all();
        $this->load->view('admin/servicosadm/list', $data);
    }
    public function delete($id)
    {
        if (!empty($id) && is_numeric($id)) {
            $servico = $this->ServicosAdm_model->get_where(array('id' => $id));
            if ($servico) {
                unlink('uploads/servicos/' . $servico->imagem);
                $this->ServicosAdm_model->delete(array('id' => $id));
                $this->session->set_flashdata('mensagem', 'Serviço removido com sucesso');
            } else {
                $this->session->set_flashdata('mensagem', 'Serviço não existe.');
            }
        } else {
            $this->session->set_flashdata('mensagem', 'Serviço não encontrado');
        }
        redirect(base_url('Admin/Servicosadm/list'));
    }
    public function create()
    {
        $data['titulo'] = 'Cadastrar serviço';
        $data['id'] = '';
        $data['action'] = base_url('admin/servicosadm/create_action');
        $data['descricao'] = set_value('descricao');
        $data['imagem'] = set_value('imagem');
        $this->load->view('admin/servicosadm/form', $data);
    }
    public function create_action()
    {
        $this->_validationRules();
        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $insert = array(
                'descricao' => $this->input->post('descricao'),
                'imagem' => $this->input->post('imagem'),
            );
            $servico = $this->ServicosAdm_model->insert($insert);
            if ($servico) {
                $this->_configsUpload();
                if (!$this->upload->do_upload('imagem')) {
                    $this->session->set_flashdata('mensagem', $this->upload->display_errors());
                    redirect(base_url('servicos'));
                    exit();
                } else {
                    $upload = $this->upload->data();
                    $this->ServicosAdm_model->update($servico, array('imagem' => $upload['file_name']));
                }
                $this->session->set_flashdata('mensagem', 'Serviço cadastrado com sucesso');
            } else {
                $this->session->set_flashdata('mensagem', 'Falha ao cadastrar o serviço');
            }
            redirect(base_url('admin/servicosadm'));
        }
    }
    public function update($id)
    {
        $servico = $this->ServicosAdm_model->get_where(array('id' => $id));
        if ($servico) {
            $data['titulo'] = 'Alterar servico';
            $data['id'] = $servico->id;
            $data['action'] = base_url('adm/servicosadm/update_action/' . $servico->id);
            $data['descricao'] = set_value('descricao', $servico->titulo);
            $data['imagem'] = $servico->imagem;
            $this->load->view('admin/servicosadm/form', $data);
        } else {
            $this->session->set_flashdata('mensagem', 'Serviço não encontrado.');
            redirect(base_url('servicos'));
        }
    }
    public function update_action($id)
    {
        $this->_validationRules();
        if ($this->form_validation->run() == FALSE) {
            $this->update($id);
        } else {
            $imagem = $this->input->post('imagem_aux');
            if ($_FILES['imagem']['titulo']) {
                $config = $this->_configsUpload();
                if (!$this->upload->do_upload('imagem')) {
                    $this->session->set_flashdata('mensagem', $this->upload->display_errors());
                    redirect(base_url('servicos'));
                    exit();
                } else {
                    unlink($config['upload_path'] . $imagem);
                    $upload = $this->upload->data();
                    $imagem = $upload['file_name'];
                }
            }
            $update = array(
                'descricao' => $this->input->post('descricao'),
                'imagem' => $imagem,
            );
            if ($this->ServicosAdm_model->update($id, $update)) {
                $this->session->set_flashdata('mensagem', 'Serviço alterado com sucesso');
            } else {
                $this->session->set_flashdata('mensagem', 'Falha ao alterar o serviço');
            }
            redirect(base_url('servicos'));
        }
    }
    final function _configsUpload()
    {
        $config['upload_path']          = './uploads/servicos/';
        @mkdir($config['upload_path']);
        $config['allowed_types']        = 'gif|jpg|png|pdf';
        $config['max_size']             = 2048;
        $config['max_width']            = 2048;
        $config['max_height']           = 2048;
        $config['encrypt_name']         = true;
        $this->load->library('upload', $config);
        return $config;
    }
    final function _validationRules()
    {
        $this->form_validation->set_rules('descricao', 'descricao', 'required');
    }
}

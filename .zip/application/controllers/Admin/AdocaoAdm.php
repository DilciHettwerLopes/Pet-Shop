<?php
defined('BASEPATH') or exit('No direct script access allowed');

class AdocaoAdm extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Admin/AdocaoAdm_model');
        $this->load->library('form_validation');
    }
    public function index()
    {
        $data['adocoes'] = $this->AdocaoAdm_model->get_all();
        $this->load->view('admin/adocaoadm/list', $data);
    }
    public function delete($id)
    {
        if (!empty($id) && is_numeric($id)) {
            $adocao = $this->AdocaoAdm_model->get_where(array('id' => $id));
            if ($adocao) {
                unlink('uploads/adocao/' . $adocao->imagem);
                $this->AdocaoAdm_model->delete(array('id' => $id));
                $this->session->set_flashdata('mensagem', 'Adoção removida com sucesso');
            } else {
                $this->session->set_flashdata('mensagem', 'Adoção não existe.');
            }
        } else {
            $this->session->set_flashdata('mensagem', 'Adoção não encontrado');
        }
        redirect(base_url('adocaoadm/list'));
    }
    public function create()
    {
        $data['titulo'] = 'Cadastrar adocao';
        $data['id'] = '';
        $data['action'] = base_url('adocaoadm/create_action');
        $data['descricao'] = set_value('descricao');
        $data['imagem'] = set_value('imagem');
        $this->load->view('adocaoadm/form', $data);
    }
    public function create_action()
    {
        $this->_validationRules();
        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $insert = array(
                'descricao' => $this->input->post('descricao'),
                'imagem' => $this->input->post('imagem'),
            );
            $adocao = $this->AdocaoAdm_model->insert($insert);
            if ($adocao) {
                $this->_configsUpload();
                if (!$this->upload->do_upload('imagem')) {
                    $this->session->set_flashdata('mensagem', $this->upload->display_errors());
                    redirect(base_url('adocoes'));
                    exit();
                } else {
                    $upload = $this->upload->data();
                    $this->AdocaoAdm_model->update($adocao, array('imagem' => $upload['file_name']));
                }
                $this->session->set_flashdata('mensagem', 'Adoção cadastrada com sucesso');
            } else {
                $this->session->set_flashdata('mensagem', 'Falha ao cadastrar a adocao');
            }
            redirect(base_url('adocaoadm'));
        }
    }
    public function update($id)
    {
        $adocao = $this->AdocaoAdm_model->get_where(array('id' => $id));
        if ($adocao) {
            $data['titulo'] = 'Alterar adocao';
            $data['id'] = $adocao->id;
            $data['action'] = base_url('adocao/update_action/' . $adocao->id);
            $data['descricao'] = set_value('descricao', $adocao->titulo);
            $data['imagem'] = $adocao->imagem;
            $this->load->view('adocaoadm/form', $data);
        } else {
            $this->session->set_flashdata('mensagem', 'Adocao não encontrada.');
            redirect(base_url('adocoes'));
        }
    }
    public function update_action($id)
    {
        $this->_validationRules();
        if ($this->form_validation->run() == FALSE) {
            $this->update($id);
        } else {
            $imagem = $this->input->post('imagem_aux');
            if ($_FILES['imagem']['titulo']) {
                $config = $this->_configsUpload();
                if (!$this->upload->do_upload('imagem')) {
                    $this->session->set_flashdata('mensagem', $this->upload->display_errors());
                    redirect(base_url('adocoes'));
                    exit();
                } else {
                    unlink($config['upload_path'] . $imagem);
                    $upload = $this->upload->data();
                    $imagem = $upload['file_name'];
                }
            }
            $update = array(
                'descricao' => $this->input->post('descricao'),
                'imagem' => $imagem,
            );
            if ($this->AdocaoAdm_model->update($id, $update)) {
                $this->session->set_flashdata('mensagem', 'Adocao alterada com sucesso');
            } else {
                $this->session->set_flashdata('mensagem', 'Falha ao alterar a adoção');
            }
            redirect(base_url('adocoes'));
        }
    }
    final function _configsUpload()
    {
        $config['upload_path']          = './uploads/adocao/';
        @mkdir($config['upload_path']);
        $config['allowed_types']        = 'gif|jpg|png|pdf';
        $config['max_size']             = 2048;
        $config['max_width']            = 2048;
        $config['max_height']           = 2048;
        $config['encrypt_name']         = true;
        $this->load->library('upload', $config);
        return $config;
    }
    final function _validationRules()
    {
        $this->form_validation->set_rules('titulo', 'titulo', 'required');
        $this->form_validation->set_rules('descricao', 'descricao', 'required');
    }
}

<?php
class Produtos extends MY_Controller{

    public function __construct(){
 parent:: __construct();
 $this->load->model('Produtos_model');
    }
         
    public function index()
    {
        
        $data['produtos'] = $this->Produtos_model->getList();
        $this->load->view('produtos/index', $data);
    }

    public function detalhes($id=''){
       if(empty($id)){
           show_404();
       } else{
        $data['produto'] = $this->Produtos_model->getwhere(array('id'=>$id));
        $this->load->view('produtos/detalhes', $data);
       }
    }
}
<?php
class Adocao extends MY_Controller{

    public function __construct(){
 parent:: __construct();
 $this->load->model('Adocao_model');
    }
         
    public function index()
    {
        
        $data['animais'] = $this->Adocao_model->getList();
        $this->load->view('adocao/index', $data);
    }

    public function detalhes($id=''){
       if(empty($id)){
           show_404();
       } else{
        $data['adocao'] = $this->Adocao_model->getwhere(array('id'=>$id));
        $this->load->view('adocao/detalhes', $data);
       }
    }
}
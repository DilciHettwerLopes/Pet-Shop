<?php
class Sobre extends MY_Controller{

    public function __construct(){
 parent:: __construct();
 $this->load->model('Sobre_model');
    }
         
    public function index()
    {
        
        $data['sobre'] = $this->Sobre_model->getList();
        $this->load->view('sobre/index', $data);
    }

    public function detalhes($id=''){
       if(empty($id)){
           show_404();
       } else{
        $data['sobre'] = $this->Cursos_model->getwhere(array('id'=>$id));
        $this->load->view('sobre/detalhes', $data);
       }
    }
}
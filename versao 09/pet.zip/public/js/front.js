$(document).ready(function () {

  //formulario
  $('#form-contato').validate({
    rules: {
      nome: 'required',
      email: 'required',
      telefone: 'required',
      assunto: 'required',
      mensagem: 'required'

    },
    messages: {
      nome: 'Insira o nome',
      email: 'Insira a mensagem',
      telefone: 'Insira o telefone',
      assunto: 'Insira o assunto',
      mensagem: 'Insira a mensagem'

    },
    errorPlacement: function (error, element) {
      error.insertAfter(element).addClass('text-danger');
    },
    errorClass: "is-invalid"
  });

  //calendario

  var calendar = $('#calendar').fullCalendar({
    timeZone: 'America/Sao_Paulo',
    axisFormat: 'H:mm',
    timeFormat: {
      agenda: 'H:mm{ - H:mm}',
    },
    monthNames: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
    monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
    dayNames: ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sabado'],
    dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'],

    buttonText: {
      today: 'Hoje',
      month: 'Mês',
      week: 'Semana',
      day: 'Hoje',
      list: 'Lista'
    },
    defaultView: 'agendaDay',
    eventBorderColor: "#de1f1f",

    header: {
      left: 'prev,next,today',
      center: 'title',
      right: 'month,agendaWeek,agendaDay'
    },

    /* defaultDate: Date(),
     navLinks: true,
     eventLimit: true,*/

    editable: true,
    selectable: true,

    events: [{
      id: '',
      title: '',
      start: '',
      end: '',
    }],

    select: function (start, end, allDay) {
     
      $('#createEventModal').modal('show');
  },

  
  eventDrop: function (event, delta, revertFunc) {
      
  },

    eventResize: function (event, delta, revertFunc) {
     
  },

  eventRender: function(event, element) {
      $(element).tooltip({title: event.title});             
  },

   eventClick: function (event) {
      $('#modalTitle').html(event.title);
      $('#modalBody').html(event.description);
      $('#fullCalModal').modal();
  },
})

$('#submitButton').on('click', function(e){
            e.preventDefault();

      doSubmit();
    });

function doSubmit(){
  $("#createEventModal").modal('hide');
  $("#calendar").fullCalendar('renderEvent',
      {
          title: $('#eventName').val(),
          start: new Date($('#eventDueDate').val()),
      },
      true);
 }
});
-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 10-Dez-2020 às 03:04
-- Versão do servidor: 10.4.14-MariaDB
-- versão do PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `pet`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `adocao`
--

CREATE TABLE `adocao` (
  `id` int(11) NOT NULL,
  `data_adocao` date DEFAULT NULL,
  `cd_cliente` int(11) DEFAULT NULL,
  `cd_animal` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `animal`
--

CREATE TABLE `animal` (
  `id` int(11) NOT NULL,
  `nome_animal` varchar(100) DEFAULT NULL,
  `raca` varchar(100) DEFAULT NULL,
  `descricao` varchar(150) DEFAULT NULL,
  `imagem` varchar(150) DEFAULT NULL,
  `cd_cliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `animal`
--

INSERT INTO `animal` (`id`, `nome_animal`, `raca`, `descricao`, `imagem`, `cd_cliente`) VALUES
(10, 'Felix', 'Vira lata ', 'Gato dorminhoco ', 'cc763b33bdb6e3591f405983bfc096e6.jpg', 0),
(13, 'Felix', 'Vira lata ', 'gato animado ', '817ee81e0e63aee3daeedce27d6e1ff9.jpg', 0),
(15, 'Fofão', 'Vira lata ', 'Filhote ', 'f622fa8eea122e90d3315addae850e77.png', 0),
(16, 'Faisca ', 'vira lata ', 'Cachorro dócil. ', '60df1778f31df6a823521e1bb7dcc33f.jpg', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `animal_servico`
--

CREATE TABLE `animal_servico` (
  `id` int(11) NOT NULL,
  `cd_animal` int(11) DEFAULT NULL,
  `cd_servico` int(11) DEFAULT NULL,
  `data_servico` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `bairro`
--

CREATE TABLE `bairro` (
  `id` int(11) NOT NULL,
  `nome_bairro` varchar(100) DEFAULT NULL,
  `cd_cidade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cidade`
--

CREATE TABLE `cidade` (
  `id` int(11) NOT NULL,
  `nome_cidade` varchar(100) DEFAULT NULL,
  `cd_estado` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `telefone` int(100) DEFAULT NULL,
  `redesocial` varchar(100) DEFAULT NULL,
  `observacao` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `endereco`
--

CREATE TABLE `endereco` (
  `id` int(11) NOT NULL,
  `nome_rua` varchar(100) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `complemento` varchar(100) DEFAULT NULL,
  `cd_bairro` int(11) DEFAULT NULL,
  `cd_cliente` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `estado`
--

CREATE TABLE `estado` (
  `id` int(11) NOT NULL,
  `nome_estado` varchar(100) DEFAULT NULL,
  `cd_pais` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `color` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `events`
--

INSERT INTO `events` (`id`, `title`, `start_date`, `end_date`, `color`) VALUES
(6, 'Reuniao ', '2020-12-10 08:20:32', '2020-12-10 11:00:32', '#0071c5'),
(7, 'Tosa ', '2020-12-15 19:28:35', '2020-12-15 19:28:35', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pais`
--

CREATE TABLE `pais` (
  `id` int(11) NOT NULL,
  `nome_pais` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--

CREATE TABLE `produto` (
  `id` int(11) NOT NULL,
  `titulo` varchar(100) DEFAULT NULL,
  `descricao` varchar(200) DEFAULT NULL,
  `imagem` varchar(200) DEFAULT NULL,
  `categoria` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `produto`
--

INSERT INTO `produto` (`id`, `titulo`, `descricao`, `imagem`, `categoria`) VALUES
(2, 'Brinquedo Chalesco Kitty Ball Cores Variadas', '- Diversão garantida;\r\n- Proporciona atividade física;\r\n- Elimina o estresse.', 'brinquedo chalesco.jpg', 'brinquedo'),
(3, 'Coleira MSD Antiparasitas Scalibor', '- Age contra pulga e carrapato depois do contato com o animal (controla a infestação no ambiente);\r\n- Possui tecnologia exclusiva e inovadora, não contém cheiro;\r\n- Garante alta proteção contra picada', 'coleira antiparasita.jpg ', 'acessorio'),
(4, 'Bolsa de Transporte Bichinho Chic Baby Azul', '- Resistente;\r\n- Prática e confortável;\r\n- Ideal para cães e gatos de pequeno porte;\r\n- Possui presilha interna para prender na coleira.', 'bolsa.jpg', 'acessorio'),
(15, 'teste ', 'teste teste ', '39f2620773f31f72d5e42dfdd407f5de.jpg', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `servico`
--

CREATE TABLE `servico` (
  `id` int(11) NOT NULL,
  `titulo` varchar(100) DEFAULT NULL,
  `descricao` varchar(200) DEFAULT NULL,
  `imagem` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `servico`
--

INSERT INTO `servico` (`id`, `titulo`, `descricao`, `imagem`) VALUES
(22, 'Banho e tosa ', 'Limpeza e higienização de cães e gatos. Incluindo o corte das unhas e escovação dos dentes. ', '97749622d4b07b62b779a8709fa997b5.jpg'),
(25, 'Passeador ', 'Contrate um herói para passear com o seu cachorro no dia e a hora que você quiser!', '71caabf3c7e7ecfbc34f3c5ed2284c71.jpg'),
(26, 'Vacina ', 'Aplicação de vacinas. Antes da aplicação o seu pet é examinado para ver se está apto a ser imunizado.', 'e85de977d2a81cc1eb1377c059b6d7c4.jpg'),
(28, 'Cirurgia ', 'Cirurgia realizada por veterinários especializados. ', '70b70780bfa98ab20b7e72508ad54410.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `servico_produto`
--

CREATE TABLE `servico_produto` (
  `id` int(11) NOT NULL,
  `cd_produto` int(11) DEFAULT NULL,
  `cd_servico` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sobre`
--

CREATE TABLE `sobre` (
  `id` int(11) NOT NULL,
  `titulo` varchar(100) DEFAULT NULL,
  `descricao` varchar(200) DEFAULT NULL,
  `imagem` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `sobre`
--

INSERT INTO `sobre` (`id`, `titulo`, `descricao`, `imagem`) VALUES
(1, 'Como tudo começou ', 'Lorem Ipsum é simplesmente uma simulação de texto da indústria tipográfica e de impressos, e vem sendo utilizado desde o século XVI, quando um impressor desconhecido pegou uma bandeja de tipos e os em', 'logo.jpg'),
(3, 'Adoção ', 'Lorem Ipsum é simplesmente uma simulação de texto da indústria tipográfica e de impressos, e vem sendo utilizado desde o século XVI, quando um impressor desconhecido pegou uma bandeja de tipos e os em', 'frase.jpg'),
(16, 'Missão ', 'Proporcionar aos nossos clientes o melhor em serviços e produtos de Pet Shop transmitindo qualidade e confiança através do amor que temos pelos bichinhos para todos que sentem necessidade de cuidar do', 'capa.jpg'),
(17, 'Visão ', 'Estar em um patamar elevado de atendimento, sendo uma empresa de referência no ramo de pet shop na região extremoeste catarinense.', '15371a.jpg'),
(18, 'Valores', 'Amor e dedicação aos pets;  Higiene e qualidade de serviços;  Atendimento especializado;  Ética profissional;  Trabalho em equipe;  Competência na segurança.\r\n', '254157-P48ON3-118.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `senha` varchar(200) DEFAULT NULL,
  `funcao` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id`, `nome`, `email`, `senha`, `funcao`) VALUES
(1, 'Dilci ', 'dilcylopes@gmail.com', '123', 'administracao');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `adocao`
--
ALTER TABLE `adocao`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cd_cliente` (`cd_cliente`),
  ADD KEY `cd_animal` (`cd_animal`);

--
-- Índices para tabela `animal`
--
ALTER TABLE `animal`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `animal_servico`
--
ALTER TABLE `animal_servico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `animal_servico_servico` (`cd_servico`),
  ADD KEY `fk_cd_ animal` (`cd_animal`);

--
-- Índices para tabela `bairro`
--
ALTER TABLE `bairro`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bairro_cidade` (`cd_cidade`);

--
-- Índices para tabela `cidade`
--
ALTER TABLE `cidade`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cidade_estado` (`cd_estado`);

--
-- Índices para tabela `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `endereco`
--
ALTER TABLE `endereco`
  ADD PRIMARY KEY (`id`),
  ADD KEY `endereco_bairro` (`cd_bairro`),
  ADD KEY `endereco_cliente` (`cd_cliente`);

--
-- Índices para tabela `estado`
--
ALTER TABLE `estado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `estado_pais` (`cd_pais`);

--
-- Índices para tabela `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `pais`
--
ALTER TABLE `pais`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `produto`
--
ALTER TABLE `produto`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `servico`
--
ALTER TABLE `servico`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `servico_produto`
--
ALTER TABLE `servico_produto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `servico_produto_servico` (`cd_servico`),
  ADD KEY `servico_produto_produto` (`cd_produto`);

--
-- Índices para tabela `sobre`
--
ALTER TABLE `sobre`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `adocao`
--
ALTER TABLE `adocao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `animal`
--
ALTER TABLE `animal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `animal_servico`
--
ALTER TABLE `animal_servico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `bairro`
--
ALTER TABLE `bairro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `cidade`
--
ALTER TABLE `cidade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `cliente`
--
ALTER TABLE `cliente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `endereco`
--
ALTER TABLE `endereco`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `estado`
--
ALTER TABLE `estado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `pais`
--
ALTER TABLE `pais`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `produto`
--
ALTER TABLE `produto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `servico`
--
ALTER TABLE `servico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de tabela `servico_produto`
--
ALTER TABLE `servico_produto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `sobre`
--
ALTER TABLE `sobre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `adocao`
--
ALTER TABLE `adocao`
  ADD CONSTRAINT `fk_cd_animal` FOREIGN KEY (`cd_animal`) REFERENCES `animal` (`id`),
  ADD CONSTRAINT `fk_cliente` FOREIGN KEY (`cd_cliente`) REFERENCES `cliente` (`id`);

--
-- Limitadores para a tabela `animal_servico`
--
ALTER TABLE `animal_servico`
  ADD CONSTRAINT `animal_servico_servico` FOREIGN KEY (`cd_servico`) REFERENCES `servico` (`id`),
  ADD CONSTRAINT `fk_cd_ animal` FOREIGN KEY (`cd_animal`) REFERENCES `animal` (`id`);

--
-- Limitadores para a tabela `bairro`
--
ALTER TABLE `bairro`
  ADD CONSTRAINT `bairro_cidade` FOREIGN KEY (`cd_cidade`) REFERENCES `cidade` (`id`);

--
-- Limitadores para a tabela `cidade`
--
ALTER TABLE `cidade`
  ADD CONSTRAINT `cidade_estado` FOREIGN KEY (`cd_estado`) REFERENCES `estado` (`id`);

--
-- Limitadores para a tabela `endereco`
--
ALTER TABLE `endereco`
  ADD CONSTRAINT `endereco_bairro` FOREIGN KEY (`cd_bairro`) REFERENCES `bairro` (`id`),
  ADD CONSTRAINT `endereco_cliente` FOREIGN KEY (`cd_cliente`) REFERENCES `cliente` (`id`);

--
-- Limitadores para a tabela `estado`
--
ALTER TABLE `estado`
  ADD CONSTRAINT `estado_pais` FOREIGN KEY (`cd_pais`) REFERENCES `pais` (`id`);

--
-- Limitadores para a tabela `servico_produto`
--
ALTER TABLE `servico_produto`
  ADD CONSTRAINT `servico_produto_produto` FOREIGN KEY (`cd_produto`) REFERENCES `produto` (`id`),
  ADD CONSTRAINT `servico_produto_servico` FOREIGN KEY (`cd_servico`) REFERENCES `servico` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

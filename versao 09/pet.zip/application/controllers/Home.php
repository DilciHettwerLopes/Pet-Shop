<?php

class Home extends MY_Controller
{

   public function index()
   {
      $this->load->view('home/index');
      $this->load->library('');
   }

   public function events()
   {
      $data['result'] = $this->db->get("events")->result();

      foreach ($data['result'] as $key => $value) {
         $data['data'][$key]['title'] = $value->title;
         $data['data'][$key]['start'] = $value->start_date;
         $data['data'][$key]['end'] = $value->end_date;
         $data['data'][$key]['backgroundColor'] = "#00a65a";
      }

      $this->load->view('home/index');
   }
}

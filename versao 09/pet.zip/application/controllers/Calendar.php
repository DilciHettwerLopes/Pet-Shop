<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Calendar extends MY_Controller
{
    private $data;

    public function __construct(){
        parent::__construct();
        $this->data['url'] = $this->config->base_url();
        $this->load->model('Calendar_model');
    }

    public function index(){
        $event_data = $this->Calendar_model->get_all();
        foreach ($event_data as $row) {
            $data[] = array(
                'id' => $row->id,
                'title' => $row->title,
                'start_date' => $row->start_date,
                'end_date' => $row->end_date
            );
        }
        $this->data['events'] = json_encode($data);
        $this->load->view('agenda/index', $this->data);
    }

    public function delete($id){

        if (!empty($id) && is_numeric($id)) {
            $agenda = $this->Calendar_model->get_where($id);
            if ($this->input->post($id)) {
                $this->Calendar_model->delete_event($this->input->post($id));
                $this->session->set_flashdata('mensagem', '<div class="alert alert-success"> Evento removido com sucesso.</div>');
            } else {
                $this->session->set_flashdata('mensagem', '<div class="alert alert-danger"> Evento não existente.</div>');
            }
        }
        redirect(base_url('agenda/index'));
    }

    public function create()
    {
        if ($this->input->post('title')) {
            $data = array(
                'title' => $this->input->post('title'),
                'start_date' => $this->input->post('start_date'),
                'end_date' => $this->input->post('end_date')
            );
            $this->Calendar_model->insert_event($data);
            redirect(base_url('agenda/index'));
        }
    }

    function update($id)
    {
        if ($this->input->post('id')) {
            $data = array(
                'title'   => $this->input->post('title'),
                'start_date' => $this->input->post('start_date'),
                'end_date'  => $this->input->post('end_date')
            );

            $this->Calendar_model->update_event($data, $this->input->post('id'));
            redirect(base_url('agenda/index'));
        }
    }
}

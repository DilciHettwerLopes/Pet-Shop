<?php
class Servicos extends MY_Controller{

    public function __construct(){
 parent:: __construct();
 $this->load->model('Servicos_model');
    }
         
    public function index()
    {
        
        $data['servicos'] = $this->Servicos_model->getList();
        $this->load->view('servicos/index', $data);
    }

    public function detalhes($id=''){
       if(empty($id)){
           show_404();
       } else{
        $data['servico'] = $this->Servicos_model->getwhere(array('id'=>$id));
        $this->load->view('servicos/detalhes', $data);
       }
    }
}
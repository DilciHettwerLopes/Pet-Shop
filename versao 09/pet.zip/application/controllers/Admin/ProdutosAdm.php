<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ProdutosAdm extends CI_Controller
{
    private $data;

    public function __construct()
    {
        parent::__construct();
        $this->data['url'] = $this->config->base_url();
        $this->load->model('Admin/ProdutosAdm_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $this->load->view('admin/includesadm/header', $this->data);
        $this->data['produtos'] = $this->ProdutosAdm_model->get_all();
        $this->load->view('admin/produtosadm/list', $this->data);
        $this->load->view('admin/includesadm/footer', $this->data);
    }


    public function delete($id)
    {
        $this->load->view('admin/includesadm/header', $this->data);
        if (!empty($id) && is_numeric($id)) {
            $produto = $this->ProdutosAdm_model->get_where(array('id' => $id));
            if ($produto) {
                unlink('uploads/produtos/' . $produto->imagem);
                $this->ProdutosAdm_model->delete(array('id' => $id));
                $this->session->set_flashdata('mensagem','<div class="alert alert-success"> Produto removido com sucesso.</div>');
            } else {
                $this->session->set_flashdata('mensagem', '<div class="alert alert-danger"> Produto não encontrado </div>');
            }
        }
        redirect(base_url('admin/produtosadm'));
        $this->load->view('admin/includesadm/footer', $this->data);
    }
    public function create()
    {
        $this->load->view('admin/includesadm/header', $this->data);
        $this->data['titulo'] = '';
        $this->data['id'] = '';
        $this->data['action'] = base_url('admin/produtosadm/create_action');
        $this->data['descricao'] = set_value('descricao');
        $this->data['imagem'] = set_value('imagem');
        $this->load->view('admin/produtosadm/form', $this->data);
        $this->load->view('admin/includesadm/footer', $this->data);
    }
    public function create_action()
    {

        $this->_validationRules();
        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $insert = array(
                'titulo' => $this->input->post('titulo'),
                'descricao' => $this->input->post('descricao'),
                'imagem' => $this->input->post('imagem'),
            );
            $produto = $this->ProdutosAdm_model->insert($insert);
            if ($produto) {
                $this->_configsUpload();
                if (!$this->upload->do_upload('imagem')) {
                    $this->session->set_flashdata('mensagem', $this->upload->display_errors());
                    redirect(base_url('admin/prodrutosadm'));
                    exit();
                } else {
                    $upload = $this->upload->data();
                    $this->ProdutosAdm_model->update($produto, array('imagem' => $upload['file_name']));
                }
                $this->session->set_flashdata('mensagem', '<div class="alert alert-success"> Produto cadastrado com sucesso.</div>');
            } else {
                $this->session->set_flashdata('mensagem', '<div class="alert alert-danger"> Falha ao cadastrar o produto.</div>');
            }

            redirect(base_url('admin/prodrutosadm'));
            $this->load->view('admin/includesadm/footer', $this->data);
        }
    }
    public function update($id)
    {
        $this->load->view('admin/includesadm/header', $this->data);
        $produto = $this->ProdutosAdm_model->get_where(array('id' => $id));
        if ($produto) {
            $data['titulo'] = $produto->titulo;
            $data['id'] = $produto->id;
            $data['action'] = base_url('admin/produtosadm/update_action/' . $produto->id);
            $data['descricao'] = $produto->descricao;
            $data['imagem'] = $produto->imagem;
            $this->load->view('admin/produtosadm/form', $this->data);
        } else {
            $this->session->set_flashdata('mensagem', '<div class="alert alert-danger"> Produto não encontrado.</div>');
            redirect(base_url('admin/produtosadmin'));
            $this->load->view('admin/includesadm/footer', $this->data);
        }
    }
    public function update_action($id)
    {

        $this->_validationRules();
        if ($this->form_validation->run() == FALSE) {
            $this->update($id);
        } else {
            $imagem = $this->input->post('imagem_aux');
            if ($_FILES['imagem']['titulo']) {
                $config = $this->_configsUpload();
                if (!$this->upload->do_upload('imagem')) {
                    $this->session->set_flashdata('mensagem', $this->upload->display_errors());
                    redirect(base_url('admin/produtosadm'));
                    exit();
                } else {
                    unlink($config['upload_path'] . $imagem);
                    $upload = $this->upload->data();
                    $imagem = $upload['file_name'];
                }
            }
            $update = array(
                'titulo' => $this->input->post('titulo'),
                'descricao' => $this->input->post('descricao'),
                'imagem' => $imagem,
            );
            if ($this->ProdutosAdm_model->update($id, $update)) {
                $this->session->set_flashdata('mensagem', '<div class="alert alert-success"> Produto alterado com sucesso.</div>');
            } else {
                $this->session->set_flashdata('mensagem', '<div class="alert alert-danger"> Falha ao alterar o produto.</div>');
            }
            redirect(base_url('admin/produtosadm'));
            $this->load->view('admin/includesadm/footer', $this->data);
        }
    }
    final function _configsUpload()
    {
        $config['upload_path']          = './uploads/produtos/';
        @mkdir($config['upload_path']);
        $config['allowed_types']        = 'gif|jpg|png|pdf';
        $config['max_size']             = 2048;
        $config['max_width']            = 2048;
        $config['max_height']           = 2048;
        $config['encrypt_name']         = true;
        $this->load->library('upload', $config);
        return $config;
    }
    final function _validationRules()
    {
        $this->form_validation->set_rules('titulo', 'titulo', 'required');
        $this->form_validation->set_rules('descricao', 'descricao', 'required');
    }
}

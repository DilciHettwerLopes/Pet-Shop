<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Contato extends MY_Controller{
   public function __construct()
   {
      parent::__construct();
      $this->load->library('form_validation');
      }

   public function index(){
    $data['action'] = site_url('contato');
    $this->load->view('contato/index', $data);
   }

   public function enviar() {
      $this->load->library('email');

      $nome = $this->input->post('nome', TRUE);
      $email = $this->input->post('email', TRUE);
      $telefone = $this->input->post('telefone', TRUE);
      $assunto = $this->input->post('assunto', TRUE);
      $mensagem = $this->input->post('mensagem', TRUE);

      $this->email->from($email, $nome);
      $this->email->to('dilcylopes@gmail.com');

      $this->email->subject($assunto);
      $this->email->message('<html><head></head><body>
          Nome:       ' . $nome . ' <br />
          Telefone:   ' . $telefone . ' <br />
          Assunto:    ' . $assunto . ' <br />
          Mensagem:   ' . $mensagem . ' <br />
          </body></html>');

      $em = $this->email->send();
      if ($em) {
          $data['email_enviado'] = 'E-mail enviado com sucesso. Aguarde contato.';
      } else {
          $data['email_enviado'] = 'Erro ao enviar o email. Favor enviar um e-mail para dilcylopes@gmail.com';
      }
       $data['action'] = site_url('contato');
      $this->load->view('contato',$data);
  }

   final function _validationRules()
   {
      $this->form_validation->set_rules('nome', 'nome', 'required');
      $this->form_validation->set_rules('email', 'nome', 'required');
      $this->form_validation->set_rules('telefone', 'telefone', 'required');
      $this->form_validation->set_rules('assunto', 'assunto', 'required');
   }
}
<fieldset>
  <div class="container-fluid">
    <div class="row">
      <div class="container">

        <!-- Barra de navegação -->
        <div class="navigation">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?= $url . 'admin/adocaoadm' ?>">Adoção</a></li>
              <li class="breadcrumb-item"><a href="<?= $url . 'admin/adocaoadm/create' ?>">Cadastrar Adoção</a></li>
            </ol>
          </nav>
        </div>

        <nav class="navbar navbar-expand-lg navbar-light col-12">
          <legend><?= $nome_animal ?></legend>
          <?php echo validation_errors(); ?>
        </nav>

<!-- formulario -->
<form enctype="multipart/form-data" method="post" action="<?= $action ?>" id="form-adocao">
            <div class="form-group">
              <label for="titulo">Nome do Animal</label>
              <input type="text" class="form-control" name="nome_animal" value="<?= $nome_animal ?>" placeholder="Digite o nome do animal"><br>
            </div>
            <div class="form-group">
              <label for="descricao">Raça</label>
              <input type="text" class="form-control" name="raca" value="<?= $raca ?>" id="summernote" placeholder="Digite a raça"><br>
            </div>
            <div class="form-group">
              <label for="descricao">Descrição</label>
              <input type="text" class="form-control" name="descricao" value="<?= $descricao ?>" id="summernote" placeholder="Digite a descrição"><br>
            </div>
            <div class="form-group">
              <input name="imagem" type="file">
              <?php
              if (!empty($imagem)) {
                echo "<img src='" . $url . "uploads/{$imagem}" . "' width='150'>";
                echo "<input type='hidden' value='{$imagem}' name='imagem_aux'>";
              }
              ?>
            </div>
            <input type="submit" class="btn btn-success" value="Salvar">
          </form>
        </div>
      </div>
    </div>
</fieldset>
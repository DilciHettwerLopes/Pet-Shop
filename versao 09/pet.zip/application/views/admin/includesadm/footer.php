</div>

<footer>
   
</footer>

<script src="<?= $url;?>public/js/jquery-3.2.1.min.js"></script>
<script src="<?= $url;?>public/js/bootstrap.min.js"></script>
<script src="<?= $url;?>public/js/DataTables/datatables.min.js"></script>
<script src="<?= $url;?>public/js/jquery.validate.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/5.0.9/js/locales/pt-BR.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="<?= $url;?>public/js/site.js"></script>
</body>
</html>
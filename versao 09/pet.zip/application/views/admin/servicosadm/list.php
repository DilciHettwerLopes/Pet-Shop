<div class="container">
  <h1>Serviços</h1>

  <a href="<?= base_url('admin/servicosadm/create'); ?>" class="btn btn-primary mb-3">Cadastrar Serviço</a>
  <?= !empty($this->session->userdata('mensagem')) ? $this->session->userdata('mensagem') : null; ?>

  <table class="table table-striped" data-toggle="data-tables" style="width:100%">
    <thead>
      <tr>
        <th scope="col" width="5%">Id</th>
        <th scope="col" width="10%">Titulo</th>
        <th scope="col" width="30%">Descricao</th>
        <th scope="col" width="35%">Imagem</th>
        <th scope="col" width="20%">Opções</th>
      </tr>
    </thead>
    <tbody>
      <?php
      foreach ($servicos as $s) {
      ?>

        <tr>
          <td ><?= $s->id; ?></td>
          <td ><?= $s->titulo; ?></td>
          <td ><?= $s->descricao; ?></td>
          <td ><img src="<?= $url . 'uploads/servicos/' . $s->imagem; ?>" alt="<?= $s->titulo ?>" width='40'></td>
          <td >
              <a class="btn btn-success" href="<?= base_url('admin/servicosadm/update/' . $s->id) ?>">Alterar</a>
              <a class="btn btn-danger" href="<?= base_url('admin/servicosadm/delete/' . $s->id) ?>">Apagar</a>
          </td>
        </tr>

      <?php
      } ?>
    </tbody>
  </table>
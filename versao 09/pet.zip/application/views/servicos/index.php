<!-- Barra de navegação -->
<div class="navigation">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?=base_url()?>">Página Inicial</a></li>
      <li class="breadcrumb-item"><a href="<?=base_url('servicos')?>">Serviços</a></li>
    </ol>
  </nav>
</div>

<h4>Conheça os nossos serviços</h4>
<div class="row mb-2">
  <?php
  foreach ($servicos as $s) {
  ?>
    <div class="col-md-4 container-fluid d-flex flex-wra">
      <div class="card mb-4 box-shadow w-100">
        <img class="card-img-top" height="200" width="150" src="uploads/servicos/<?=$s->imagem?>" alt="<?= $s->titulo ?>">
        <div class="card-body d-flex flex-column">
          <h5 class="card-title"><?= $s->titulo ?></h5>
          <p class="card-text"><?= $s->descricao ?>
          </p>
          <div class="d-flex justify-content-between align-items-center">
            <div class="btn-group" >
              <a href="<?= base_url('servicos/detalhes/' . $s->id) ?>" class="btn btn-primary mt-auto">+ detalhes</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php
  }
  ?>
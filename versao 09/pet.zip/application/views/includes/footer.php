</div>

<footer>
    <hr>
    <section>
        <div class="container bg-light">
            <br>
            <div class="row">

                <div class="col-sm">
                    <h5 class="card-title text-primary"><strong>Como podemos ajudar você? </strong></h5>
                    <p class="card-text">Conheça mais sobre nossa empresa e tenha o melhor atendimento do mercado pet 😍</p>
                    <a href="mailto:sac@petlove.com.br" class="link footer__link">sac@petmimo.com.br</a></p>
                </div>
                <div class="col-6">
                    <h4 class="text-primary"><svg class="bi bi-clock" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 108 1a7 7 0 000 14zm8-7A8 8 0 110 8a8 8 0 0116 0z" clip-rule="evenodd" />
                            <path fill-rule="evenodd" d="M 7.5 3a.5.5 0 01.5.5v5.21l3.248 1.856a.5.5 0 01-.496.868l-3.5-2A.5.5 0 017 9V3.5a.5.5 0 01.5-.5z" clip-rule="evenodd" />
                        </svg> <strong> Atendimento </strong></h4>
                    <p>Segunda-feira a sexta-feira das 8h às 12h e das 13h30 às 18h</p>
                    <h5 class="fas fa-phone text-primary"> Telefone </h5>
                    <p> (49) 99999999</p>
                </div>
                <div class="col-sm">

                    <h5 class="text-primary"> <strong> Formas de Pagamento </strong></h5>
                    <i class="far fa-credit-card"></i>
                    <i class="fab fa-cc-mastercard"></i>
                    <i class="fab fa-cc-visa"></i>

                    <h5 class="text-primary md-3"> <strong> Onde nos encontrar </strong></h5>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-facebook-square"></i>

                </div>
            </div>
        </div>
    </section>
</footer>

<script src="public/js/jquery-3.2.1.min.js"></script>
<script src="public/js/jquery.validate.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"> </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.js"></script>
<script src="public/js/front.js"></script>

</body>

</html>
<!-- Barra de navegação -->
<div class="navigation">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url() ?>">Página Inicial</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('agenda') ?>">Agenda</a></li>
        </ol>
    </nav>
</div>

<!-- calendario -->
<h1>Agenda</h1>
<p><strong> Verifique os nossos horários disponiveis.</strong></p>
<div class="container" id="calendar">
    <div class="row" style="width:50%">
        <div class="col-md-12">
            <div id="calendar">
            </div>
            <!-- modal-->
            <div class="modal fade" id="createEventModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalTitle">Qual serviço deseja agendar?</h5>
                        </div>
                        <div class="modal-body" id="modalBody">
                            <form>
                                <div class="form-group">
                                    <label for="recipient-name" class="col-form-label">Nome:</label>
                                    <input type="text" class="form-control" id="recipient-name">
                                </div>
                                <div class="form-group">
                                    <label for="text" class="col-form-label">Telefone:</label>
                                    <textarea class="form-control" id="message-text"></textarea>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer" id="fullCalModal">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                            <button type="button" class="btn btn-primary">Salvar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        let eventos = "<?php echo $events ?>";
    </script>
 <!-- antigo -->
 </div>
        <div id="createEventModal" class="modal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span> <span class="sr-only">Fechar</span></button>
                        <h4>Qual serviço deseja agendar?</h4>
                    </div>
                    <div id="modalBody" class="modal-body">
                        <div class="form-group">
                            <input class="form-control" type="text" placeholder="Event Name" id="eventName">
                        </div>

                        <div class="form-group form-inline">
                            <div class="input-group date" data-provide="datepicker">
                                <input type="text" id="eventDueDate" class="form-control" placeholder="Due Date mm/dd/yyyy">
                                <div class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <textarea class="form-control" type="text" rows="4" placeholder="Event Description" id="eventDescription"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn" data-dismiss="modal" aria-hidden="true">Cancelar</button>
                        <button type="submit" class="btn btn-primary" id="submitButton">Salvar</button>
                    </div>
                </div>
            </div>
        </div>
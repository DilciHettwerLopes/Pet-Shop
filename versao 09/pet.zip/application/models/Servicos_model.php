<?php

class Servicos_model extends CI_Model{
    public function getList() {
        $query = $this->db->get('servico');
         return $query->result();
        // result é só uma linha
         // ver a ultima query executada echo $this->db->last_query();
    }

    public function getwhere($where) {
        $this->db->where($where);
        return $this->db->get('servico')->row();
        //row é mais de uma linha

    }
}